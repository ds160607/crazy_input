package com.ds160607.crazyinput.client;

import com.google.gwt.user.client.ui.ListBox;


public class PseudoTextBox extends ListBox {
		
		public PseudoTextBox() {
			super();
		}		
		public void setValue() {			
		}
		public String getValue() {
			return "";
		}
	}
